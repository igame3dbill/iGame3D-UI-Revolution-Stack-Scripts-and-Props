#ifndef __CONFIG_TYPES_H__
#define __CONFIG_TYPES_H__

/* these are filled in by configure */
#define ogg_int16_t SInt16
#define ogg_uint16_t UInt16
#define ogg_int32_t SInt32
#define ogg_uint32_t UInt32


typedef struct ogg_int64_t
{
signed long lo;
signed long hi;
} ogg_int64_t;


#endif
